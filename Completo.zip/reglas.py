"""Reglas de conjugación y gramática del editor.

- Conjugación castellana: los verbos regulares se generan por reglas (-ar, -er, -ir);
  solo los irregulares frecuentes necesitan tabla propia.
- Formas verbales y flexiones en esperanto (volas, hundon, grandaj…).
- Concordancia adjetivo-sustantivo y notas de matiz, leídas desde datos/gramatica.json.
"""
import json
import re
import unicodedata
from pathlib import Path

PERSONAS = ["yo", "tú", "él / ella / usted", "nosotros", "ellos / ustedes"]

VERBOS_IRREGULARES = {
    "querer": ["quiero", "quieres", "quiere", "queremos", "quieren"],
    "poder": ["puedo", "puedes", "puede", "podemos", "pueden"],
    "tener": ["tengo", "tienes", "tiene", "tenemos", "tienen"],
    "venir": ["vengo", "vienes", "viene", "venimos", "vienen"],
    "ir": ["voy", "vas", "va", "vamos", "van"],
    "ser": ["soy", "eres", "es", "somos", "son"],
    "estar": ["estoy", "estás", "está", "estamos", "están"],
    "hacer": ["hago", "haces", "hace", "hacemos", "hacen"],
    "decir": ["digo", "dices", "dice", "decimos", "dicen"],
    "ver": ["veo", "ves", "ve", "vemos", "ven"],
    "saber": ["sé", "sabes", "sabe", "sabemos", "saben"],
    "dar": ["doy", "das", "da", "damos", "dan"],
    "entender": ["entiendo", "entiendes", "entiende", "entendemos", "entienden"],
    "volver": ["vuelvo", "vuelves", "vuelve", "volvemos", "vuelven"],
    "poner": ["pongo", "pones", "pone", "ponemos", "ponen"],
    "salir": ["salgo", "sales", "sale", "salimos", "salen"],
    "traer": ["traigo", "traes", "trae", "traemos", "traen"],
}
PRETERITO_IRREG = {
    "querer": ["quise", "quisiste", "quiso", "quisimos", "quisieron"],
    "poder": ["pude", "pudiste", "pudo", "pudimos", "pudieron"],
    "tener": ["tuve", "tuviste", "tuvo", "tuvimos", "tuvieron"],
    "venir": ["vine", "viniste", "vino", "vinimos", "vinieron"],
    "hacer": ["hice", "hiciste", "hizo", "hicimos", "hicieron"],
    "decir": ["dije", "dijiste", "dijo", "dijimos", "dijeron"],
    "ir": ["fui", "fuiste", "fue", "fuimos", "fueron"],
    "ser": ["fui", "fuiste", "fue", "fuimos", "fueron"],
    "estar": ["estuve", "estuviste", "estuvo", "estuvimos", "estuvieron"],
    "saber": ["supe", "supiste", "supo", "supimos", "supieron"],
    "dar": ["di", "diste", "dio", "dimos", "dieron"],
    "poner": ["puse", "pusiste", "puso", "pusimos", "pusieron"],
    "ver": ["vi", "viste", "vio", "vimos", "vieron"],
    "traer": ["traje", "trajiste", "trajo", "trajimos", "trajeron"],
}
IMPERFECTO_IRREG = {
    "ser": ["era", "eras", "era", "éramos", "eran"],
    "ir": ["iba", "ibas", "iba", "íbamos", "iban"],
    "ver": ["veía", "veías", "veía", "veíamos", "veían"],
}
FUTURO_RAIZ_IRREG = {
    "querer": "querr", "poder": "podr", "tener": "tendr", "venir": "vendr",
    "hacer": "har", "decir": "dir", "saber": "sabr", "poner": "pondr",
    "salir": "saldr", "valer": "valdr", "haber": "habr",
}
DESINENCIAS_PRES = {"ar": ["o", "as", "a", "amos", "an"],
                    "er": ["o", "es", "e", "emos", "en"],
                    "ir": ["o", "es", "e", "imos", "en"]}
DESINENCIAS_PRET = {"ar": ["é", "aste", "ó", "amos", "aron"],
                    "er": ["í", "iste", "ió", "imos", "ieron"],
                    "ir": ["í", "iste", "ió", "imos", "ieron"]}
DESINENCIAS_IMP = {"ar": ["aba", "abas", "aba", "ábamos", "aban"],
                   "er": ["ía", "ías", "ía", "íamos", "ían"],
                   "ir": ["ía", "ías", "ía", "íamos", "ían"]}
DESINENCIAS_FUT = ["é", "ás", "á", "emos", "án"]
DESINENCIAS_COND = ["ía", "ías", "ía", "íamos", "ían"]

# Terminaciones verbales y flexiones del esperanto
EO_VERBO = [("as", "presente"), ("is", "pasado"), ("os", "futuro"),
            ("us", "condicional"), ("u", "imperativo")]
EO_FLEXION = [("ajn", "plural y acusativo"), ("aj", "plural"),
              ("jn", "plural y acusativo"), ("j", "plural"), ("n", "acusativo")]

RUTA_REGLAS = Path(__file__).resolve().parent / "datos" / "gramatica.json"


def sin_tildes(s: str) -> str:
    return "".join(c for c in unicodedata.normalize("NFD", s)
                   if unicodedata.category(c) != "Mn").lower()


# ---------- Conjugación castellana ----------

def construir_formas_es(infinitivos) -> dict:
    """Devuelve {forma_sin_tildes: (infinitivo, tiempo, persona, terminacion_eo)}.

    Solo genera formas para infinitivos -ar, -er, -ir. Los verbos con cambio de raíz
    (dormir → duermo) necesitan estar en VERBOS_IRREGULARES para salir bien.
    """
    formas = {}

    def add(forma, inf, tiempo, pers, fin_eo):
        formas.setdefault(sin_tildes(forma), (inf, tiempo, pers, fin_eo))

    for inf in sorted(set(infinitivos)):
        if not re.fullmatch(r"[a-záéíóúüñ]*(ar|er|ir)", inf):
            continue
        raiz, fin = inf[:-2], inf[-2:]

        pres = VERBOS_IRREGULARES.get(inf) or [raiz + d for d in DESINENCIAS_PRES[fin]]
        for p, f in zip(PERSONAS, pres):
            add(f, inf, "presente", p, "as")

        pret = PRETERITO_IRREG.get(inf) or [raiz + d for d in DESINENCIAS_PRET[fin]]
        for p, f in zip(PERSONAS, pret):
            add(f, inf, "pretérito", p, "is")

        imp = IMPERFECTO_IRREG.get(inf) or [raiz + d for d in DESINENCIAS_IMP[fin]]
        for p, f in zip(PERSONAS, imp):
            add(f, inf, "imperfecto", p, "is")

        rf = FUTURO_RAIZ_IRREG.get(inf, inf)
        for p, d in zip(PERSONAS, DESINENCIAS_FUT):
            add(rf + d, inf, "futuro", p, "os")
        for p, d in zip(PERSONAS, DESINENCIAS_COND):
            add(rf + d, inf, "condicional", p, "us")
    return formas


# ---------- Esperanto ----------

def formas_eo(w: str, palabras: set):
    """Si w es una forma flexionada conocida, devuelve (lema, clase, tipo). Si no, None.

    clase: 'verbo' o 'flexion'.
    """
    for fin, tiempo in EO_VERBO:
        if w.endswith(fin) and len(w) > len(fin) + 1:
            inf = w[:-len(fin)] + "i"
            if inf in palabras:
                return inf, "verbo", tiempo
    for fin, tipo in EO_FLEXION:
        if w.endswith(fin) and len(w) > len(fin) + 1:
            base = w[:-len(fin)]
            for cand in (base + "o", base + "a", base + "e", base):
                if cand in palabras:
                    return cand, "flexion", tipo
    return None


# ---------- Datos editables ----------

def cargar_reglas(ruta: Path = RUTA_REGLAS) -> dict:
    """Lee datos/gramatica.json. Si falta, devuelve reglas vacías (la app sigue funcionando)."""
    if not ruta.exists():
        return {"concordancia": {}, "notas": []}
    return json.loads(ruta.read_text(encoding="utf-8"))


def revisar_concordancia(texto: str, tokens, pos, mensajes: dict) -> list:
    """Adjetivo y sustantivo pegados deben concordar en número.

    tokens: lista de (palabra, inicio, fin). pos: función palabra → categoría ('adj', 'noun').
    """
    issues = []
    for (a, ai, af), (n, ni, nf) in zip(tokens, tokens[1:]):
        if texto[af:ni].strip():
            continue  # no son vecinos inmediatos
        al, nl = a.lower(), n.lower()
        if pos(al) != "adj" or pos(nl) != "noun":
            continue
        if al.endswith("aj") and nl.endswith("o"):
            sug = al[:-1]
            clave = "a_singular"
        elif al.endswith("a") and nl.endswith("oj"):
            sug = al + "j"
            clave = "a_plural"
        else:
            continue
        plantilla = mensajes.get(clave, "«{adj}» no concuerda con «{sust}».")
        issues.append({"tipo": "error", "ini": ai, "fin": af, "texto": a,
                       "mensaje": plantilla.format(adj=a, sust=n, sugerencia=sug),
                       "sugerencias": [sug]})
    return issues


def revisar_notas(tokens, reglas: dict) -> list:
    """Notas de matiz definidas en datos/gramatica.json.

    Cada regla: {"palabra": ..., "mensaje": ..., opcional "antes": ..., opcional "no_antes": ...}
    """
    issues = []
    for i, (orig, ini, fin) in enumerate(tokens):
        ol = orig.lower()
        anterior = tokens[i - 1][0].lower() if i > 0 else ""
        for regla in reglas.get("notas", []):
            if regla.get("palabra") != ol:
                continue
            if "antes" in regla and regla["antes"] != anterior:
                continue
            if "no_antes" in regla and regla["no_antes"] == anterior:
                continue
            ini_nota = tokens[i - 1][1] if "antes" in regla else ini
            texto_nota = f"{tokens[i - 1][0]} {orig}" if "antes" in regla else orig
            issues.append({"tipo": "nota", "ini": ini_nota, "fin": fin, "texto": texto_nota,
                           "mensaje": regla["mensaje"], "sugerencias": []})
            break
    return issues
