"""Importa desde el extracto bruto de Wiktionary en castellano (raw-wiktextract-data.jsonl).

Qué saca:
- De las entradas en esperanto (lang_code = "eo"): la categoría gramatical (noun, adj…).
  Se usa para la concordancia adjetivo-sustantivo. Solo rellena lo que está vacío.
- De las entradas en castellano (lang_code = "es") con traducciones a esperanto
  (lista "translations" con lang_code = "eo"): pares castellano→esperanto (fuente = 'eswiktionary').

No toca las glosas en castellano de las entradas en esperanto (son definiciones, no traducciones).

Es un archivo de ~1,2 GB: se lee línea a línea y no se carga entero en memoria.
Haz copia de seguridad de data/diccionario.db antes de ejecutarlo.

Uso (desde la carpeta del proyecto):
    python tools/importar_eswiktionary.py data/diccionario.db raw-wiktextract-data.jsonl
"""
import json
import sqlite3
import sys
from pathlib import Path


def leer(ruta: Path):
    """Devuelve (categorias_eo, pares) a partir del JSONL.

    categorias_eo: {eo: pos}          pares: set de (es, eo)
    """
    categorias_eo = {}
    pares = set()
    entradas_eo = entradas_es = lineas = 0
    with ruta.open(encoding="utf-8") as f:
        for linea in f:
            lineas += 1
            if '"eo"' not in linea:
                continue  # descarte rápido: la inmensa mayoría de líneas no nos interesa
            try:
                d = json.loads(linea)
            except json.JSONDecodeError:
                continue
            lang = d.get("lang_code")
            palabra = (d.get("word") or "").strip().lower()
            if not palabra or " " in palabra:
                continue

            if lang == "eo":
                entradas_eo += 1
                pos = d.get("pos")
                if pos and palabra not in categorias_eo:
                    categorias_eo[palabra] = pos

            elif lang == "es":
                traducciones = [t for t in d.get("translations", [])
                                if t.get("lang_code") == "eo"]
                if not traducciones:
                    continue
                entradas_es += 1
                for t in traducciones:
                    eo = (t.get("word") or "").strip().lower()
                    if eo and " " not in eo:
                        pares.add((palabra, eo))

    print(f"Líneas leídas: {lineas}")
    print(f"Entradas en esperanto: {entradas_eo}")
    print(f"Entradas en castellano con traducción a esperanto: {entradas_es}")
    return categorias_eo, pares


def importar(ruta_db: Path, ruta_jsonl: Path) -> None:
    categorias_eo, pares = leer(ruta_jsonl)

    con = sqlite3.connect(ruta_db)
    con.execute(
        """CREATE TABLE IF NOT EXISTS es_a_eo_propio (
               es_norm TEXT NOT NULL,
               eo      TEXT NOT NULL,
               fuente  TEXT DEFAULT 'traduccion propia',
               PRIMARY KEY (es_norm, eo))"""
    )

    existentes = {r[0] for r in con.execute("SELECT eo_norm FROM entradas")}
    existentes_pares = {(r[0], r[1]) for r in con.execute(
        "SELECT es_norm, eo FROM es_a_eo_propio")}

    # 1) Categorías: rellenar las que faltan y añadir palabras nuevas
    actualizadas = nuevas = 0
    for eo, pos in categorias_eo.items():
        if eo in existentes:
            cur = con.execute(
                "UPDATE entradas SET categoria = ? WHERE eo_norm = ? AND categoria IS NULL",
                (pos, eo))
            actualizadas += cur.rowcount
        else:
            con.execute(
                """INSERT INTO entradas (eo, eo_norm, categoria, es, en, fuente)
                   VALUES (?, ?, ?, NULL, NULL, 'eswiktionary')""", (eo, eo, pos))
            existentes.add(eo)
            nuevas += 1

    # 2) Pares castellano→esperanto
    pares_nuevos = pares_ya = 0
    for es, eo in pares:
        if (es, eo) in existentes_pares:
            pares_ya += 1
            continue
        if eo not in existentes:
            con.execute(
                """INSERT INTO entradas (eo, eo_norm, categoria, es, en, fuente)
                   VALUES (?, ?, ?, NULL, NULL, 'eswiktionary')""",
                (eo, eo, categorias_eo.get(eo)))
            existentes.add(eo)
            nuevas += 1
        con.execute(
            "INSERT OR IGNORE INTO es_a_eo_propio (es_norm, eo, fuente) "
            "VALUES (?, ?, 'eswiktionary')", (es, eo))
        existentes_pares.add((es, eo))
        pares_nuevos += 1

    con.commit()
    con.close()
    print(f"Categorías rellenadas en palabras existentes: {actualizadas}")
    print(f"Palabras de esperanto nuevas: {nuevas}")
    print(f"Pares castellano→esperanto nuevos: {pares_nuevos}")
    print(f"Pares que ya existían (no tocados): {pares_ya}")


if __name__ == "__main__":
    if len(sys.argv) != 3:
        print(__doc__)
        sys.exit(1)
    importar(Path(sys.argv[1]), Path(sys.argv[2]))
