"""Análisis del texto: palabras mal escritas, formas verbales, concordancia y notas de matiz.

- Acentos: una palabra en esperanto debe escribirse con sus acentos (ĉ ĝ ĥ ĵ ŝ ŭ) o con el
  sistema x (cx gx hx jx sx ux). Si falta el acento y el diccionario tiene la forma acentuada,
  se marca y se sugiere (p. ej. «hodiau» → «hodiaŭ»).
- Palabras mal escritas: una palabra que no existe se marca como error si se parece a una
  palabra real (p. ej. «mangi» → «manĝi (comer)»).
- Formas: una forma flexionada reconocida (volas, hundon, grandaj…) se explica con su lema
  y su traducción (p. ej. «volas» → presente de «voli» (querer)).
- Castellano: con traducción se indica cuál es; las conjugaciones se explican con su forma en
  esperanto; sin traducción se marca.
- Concordancia: adjetivo y sustantivo pegados deben concordar en número.
- Notas: explicaciones de matiz definidas en datos/gramatica.json (p. ej. «poste»).
"""
import difflib
import re
import unicodedata

from reglas import cargar_reglas, formas_eo, revisar_concordancia, revisar_notas

PALABRA = re.compile(r"[A-Za-zÁÉÍÓÚÜÑáéíóúüñĈĉĜĝĤĥĴĵŜŝŬŭ]+")
LETRAS_ES = set("áéíóúüñÁÉÍÓÚÜÑ")
# Pronombres personales en esperanto para las formas conjugadas
PRONOMBRE_EO = {"yo": "mi", "tú": "vi", "él / ella / usted": "li", "nosotros": "ni",
                "ellos / ustedes": "ili"}
# Sistema x → letra con acento
SISTEMA_X = {"cx": "ĉ", "gx": "ĝ", "hx": "ĥ", "jx": "ĵ", "sx": "ŝ", "ux": "ŭ"}


def _sin_tildes(s: str) -> str:
    return "".join(c for c in unicodedata.normalize("NFD", s)
                   if unicodedata.category(c) != "Mn").lower()


def _es_x(w: str) -> bool:
    """True si la palabra usa el sistema x (cx, gx…) en vez de letras con acento."""
    return re.search(r"[cghjsu]x", w) is not None


def _clave(w: str) -> str:
    """Forma sin acentos: manĝi → mangi."""
    return (w.replace("ĉ", "c").replace("ĝ", "g").replace("ĥ", "h")
            .replace("ĵ", "j").replace("ŝ", "s").replace("ŭ", "u"))


def _desx(w: str) -> str:
    """Sistema x a letras con acento: hodiaux → hodiaŭ."""
    for x, letra in SISTEMA_X.items():
        w = w.replace(x, letra)
    return w


def _capitalizar(forma: str, capital: bool) -> str:
    return forma[:1].upper() + forma[1:] if capital else forma


def _sin_traduccion(original, ini, fin):
    return {"tipo": "sin_traduccion", "ini": ini, "fin": fin, "texto": original,
            "mensaje": f"«{original}» no se encuentra traducida en mi diccionario.",
            "sugerencias": []}


class Analizador:
    def __init__(self, palabras_eo: set, palabras_es: set, formas_es: dict,
                 traducciones: dict, categorias: dict = None, reglas: dict = None,
                 exactas: set = None):
        self.eo = palabras_eo
        self.es = palabras_es
        self.formas_es = formas_es
        self.traducciones = traducciones  # {eo: [castellano, ...]}
        self.es_a_eo = {}  # {castellano: [eo, ...]}, el sentido inverso
        for eo_w, ess in traducciones.items():
            for es_w in ess:
                self.es_a_eo.setdefault(es_w, []).append(eo_w)
        self.categorias = categorias or {}  # {eo_norm: 'noun' | 'adj' | 'verb' ...}
        self.reglas = reglas if reglas is not None else cargar_reglas()
        # Formas tal como están escritas en el diccionario, con sus acentos
        self.exactas = set(exactas or ())
        # {forma sin acentos: [formas con acentos]}: hodiau → hodiaŭ
        self.acentuadas = {}
        for e in self.exactas:
            k = _clave(e)
            if k != e:
                self.acentuadas.setdefault(k, []).append(e)
        # Índice sin sistema x y sin acentos: así «mangi» se compara con «manĝi», no con «mangxi»
        self.por_longitud = {}
        self.clave_a_palabras = {}
        for w in palabras_eo:
            if _es_x(w):
                continue
            clave = _clave(w)
            self.clave_a_palabras.setdefault(clave, []).append(w)
            self.por_longitud.setdefault(len(clave), []).append(clave)

    # ---------- Categorías ----------

    def _pos(self, w: str):
        """Categoría de una palabra; para una flexión, la de su lema (grandaj → adj)."""
        if w in self.categorias:
            return self.categorias[w]
        forma = formas_eo(w, self.eo)
        if forma and forma[1] == "flexion":
            return self.categorias.get(forma[0])
        return None

    def _es_copulativa(self, w: str) -> bool:
        """True si la palabra es «esti» o una forma suya (estas, estis, estos…)."""
        if w == "esti":
            return True
        f = formas_eo(w, self.eo)
        return bool(f) and f[0] == "esti" and f[1] == "verbo"

    def _tras_copulativa(self, tokens, idx):
        """Si la palabra anterior (saltando adjetivos) es un verbo copulativo, lo devuelve."""
        j = idx - 1
        for _ in range(3):
            if j < 0:
                break
            prev = tokens[j][0].lower()
            if self._es_copulativa(prev):
                return tokens[j][0]
            if self._pos(prev) != "adj":
                break
            j -= 1
        return None

    # ---------- Formas ----------

    def _traduccion(self, eo: str) -> str:
        trad = self.traducciones.get(eo, [])
        return f" ({', '.join(trad[:2])})" if trad else ""

    def reconocida(self, w: str) -> bool:
        return (w in self.eo or w in self.es or _sin_tildes(w) in self.formas_es
                or formas_eo(w, self.eo) is not None)

    def sugerencias(self, w: str):
        if len(w) < 3:
            return []
        clave = _clave(w)
        candidatas = []
        for longitud in (len(clave) - 1, len(clave), len(clave) + 1):
            candidatas += self.por_longitud.get(longitud, [])
        mejores = difflib.get_close_matches(clave, candidatas, n=3, cutoff=0.8)
        resultado = []
        for m in mejores:
            for palabra in self.clave_a_palabras.get(m, []):
                if palabra not in resultado:
                    resultado.append(palabra)
        return resultado[:3]

    # ---------- Análisis ----------

    def analizar(self, texto: str) -> list:
        """Lista de dicts: tipo, ini, fin, texto, mensaje, sugerencias."""
        issues = []
        tokens = [(m.group(0), m.start(), m.end()) for m in PALABRA.finditer(texto)]

        for idx, (original, ini, fin) in enumerate(tokens):
            w = original.lower()
            capital = original[:1].isupper()

            # 1) Esperanto escrito tal como está en el diccionario (o con sistema x)
            if w in self.exactas or _desx(w) in self.exactas:
                continue

            # 2) Castellano con traducción: se indica cuál es
            if w in self.es_a_eo and not capital:
                eos = self.es_a_eo[w]
                issues.append({"tipo": "es_traducido", "ini": ini, "fin": fin, "texto": original,
                               "mensaje": f"«{original}» en castellano = {', '.join(eos[:3])}.",
                               "sugerencias": []})
                continue

            # 3) Esperanto sin sus acentos: hodiau → hodiaŭ
            if w in self.acentuadas:
                formas = [_capitalizar(f, capital) for f in sorted(self.acentuadas[w])]
                opciones = " o ".join(f"«{f}»" for f in formas)
                issues.append({"tipo": "error", "ini": ini, "fin": fin, "texto": original,
                               "mensaje": f"«{original}» se escribe {opciones}.",
                               "sugerencias": formas})
                continue

            # 4) Palabra en esperanto sin entrada con acentos
            if w in self.eo:
                continue

            if capital:
                continue  # nombres propios: no se buscan más allá de los acentos

            # 6) Castellano sin traducción: con tilde o ñ
            if any(c in LETRAS_ES for c in original):
                issues.append(_sin_traduccion(original, ini, fin))
                continue

            # 7) Flexión en esperanto (volas, hundon, grandaj…)
            forma = formas_eo(w, self.eo)
            if forma and "acusativo" in forma[2]:
                copulativa = self._tras_copulativa(tokens, idx)
                if copulativa:
                    # El predicado tras «esti» va en nominativo: sin -n
                    issues.append({"tipo": "error", "ini": ini, "fin": fin, "texto": original,
                                   "mensaje": f"«{original}» va sin -n después de «{copulativa}» "
                                              f"(verbo copulativo): prueba «{original[:-1]}».",
                                   "sugerencias": [original[:-1]]})
                    continue
            if forma:
                lema, clase, tipo = forma
                trad = self._traduccion(lema)
                if clase == "verbo":
                    mensaje = f"«{original}»: {tipo} del verbo «{lema}»{trad}."
                else:
                    mensaje = f"«{original}»: {tipo} de «{lema}»{trad}."
                if _sin_tildes(w) in self.formas_es:
                    inf_es = self.formas_es[_sin_tildes(w)][0]
                    mensaje += f" También es una forma castellana de «{inf_es}»."
                issues.append({"tipo": "nota", "ini": ini, "fin": fin, "texto": original,
                               "mensaje": mensaje, "sugerencias": []})
                continue

            # 5) Conjugación castellana: se indica el verbo y su forma en esperanto
            if _sin_tildes(w) in self.formas_es:
                inf, tiempo, pers, fin_eo = self.formas_es[_sin_tildes(w)]
                detalle = ""
                eos = self.es_a_eo.get(inf, [])
                if eos:
                    verbo = eos[0][:-1] + fin_eo
                    pron = PRONOMBRE_EO.get(pers, "")
                    detalle = f" En esperanto: {pron} {verbo}."
                issues.append({"tipo": "es_traducido", "ini": ini, "fin": fin, "texto": original,
                               "mensaje": f"«{original}» = {tiempo} de «{inf}» ({pers}).{detalle}",
                               "sugerencias": []})
                continue

            # 8) Parecido con una palabra conocida, o sin parecido
            sug = self.sugerencias(w)
            if sug:
                opciones = " o ".join(f"«{s}»{self._traduccion(s)}" for s in sug)
                issues.append({"tipo": "error", "ini": ini, "fin": fin, "texto": original,
                               "mensaje": f"«{original}» no existe. ¿Quisiste decir {opciones}?",
                               "sugerencias": sug})
            elif len(w) > 2:
                # Sin parecido en mi diccionario: no es que no exista, solo que no lo tengo
                issues.append(_sin_traduccion(original, ini, fin))

        issues += revisar_concordancia(texto, tokens, self._pos,
                                       self.reglas.get("concordancia", {}))
        issues += revisar_notas(tokens, self.reglas)
        issues.sort(key=lambda d: d["ini"])
        return issues
